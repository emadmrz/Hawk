<?php

/**
 * Created by Emad Mirzaie on 01/09/2015.
 * Administration area messages
 */

return [

    'userUpdate' => 'User information was updated successfully' ,
    'userDelete' => 'User information was deleted successfully from database' ,

];
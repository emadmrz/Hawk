<?php

/**
 * Created by Emad Mirzaie on 01/09/2015.
 * users localization
 */

return[
    'activeStatus'=> 'Active',
    'deactiveStatus'=> 'Deactive',
    'confirmedStatus'=> 'Confirmed',
    'notConfirmedStatus'=> 'Not Confirmed'
];
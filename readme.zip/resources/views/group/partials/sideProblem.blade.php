<div class="timeline-block">
    <div class="panel panel-default share clearfix-xs">
        <div class="panel-heading panel-heading-gray title">
            پرسش
        </div>
        <div class="panel-body">
            <div class="list-item">
                <ul class="">
                    <li>
                        <a class="title" href="{{route('group.problem.create',[$group->id])}}">ثبت پرسش جدید</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="panel-footer text-center">

            <a class="see-more" href="#"><i class="fa fa-plus fa-1x"></i>مشاهده تمامی پرسش ها</a>
        </div>
    </div>
</div>
<div class="form-group">
    <p class="text-muted" style="font-size: 12px; text-align: justify">
        در skillema گروه بسازید، دوستان خود را دعوت کنید و در کنار هم مهارت های خود را تقویت نمایید.
    </p>
    <a class="btn btn-violet btn-block" href="{{ route('profile.group.create') }}"><i class="fa fa-group fa-lg"></i> ایجاد گروه جدید </a>
</div>
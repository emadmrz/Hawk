<div class="timeline-block">
    <div class="form-group">
        <a href="{{ route('profile.skill.create') }}" style="text-decoration: none" class="addon-store">
            <button type="button" class=" btn-lg btn btn-info  btn-block"><i class="fa fa-trophy fa-lg"></i> ثبت مهارت جدید </button>
        </a>
    </div>
</div>
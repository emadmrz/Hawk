<footer class="footer">
    <div class="copyright">
        <div class="container">
            <div class="text-center">کلیه حقوق مادی و معنوی این شبکه در اختیار Skillema بوده و هر گونه کپی برداری غیر مجاز است.<div class="pull-left">© کپی رایت ۱۳۹۴</div></div>
        </div>
    </div>
</footer>
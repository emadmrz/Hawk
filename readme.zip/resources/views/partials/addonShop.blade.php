<div class="timeline-block">
    <div class="form-group">
        <a href="{{ route('store.index') }}" style="text-decoration: none" class="addon-store">
            <button type="button" class=" btn-lg btn btn-success btn-block"><img src="{{ asset('img/icons/drum.png') }}" style="height: 23px; margin-left: 10px;"><img>شلوغش کن</button>
        </a>
    </div>
</div>
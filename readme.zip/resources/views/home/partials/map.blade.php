<div class="timeline-block">
    <div class="panel panel-default share clearfix-xs" id="collapseListGroupHeading5" role="tab">
        <div class="panel-heading panel-heading-gray title">
            <a class="collapse-title collapsed" aria-expanded="true" data-toggle="collapse" href="#collapseListGroup5" aria-expanded="true" aria-controls="collapseListGroup5">مجموعه ما روی نقشه
                <i class="status fa fa-chevron-circle-up"></i>
            </a>
        </div>
        <div class="collapse in" id="collapseListGroup5" aria-labelledby="collapseListGroupHeading2" aria-expanded="true">
            <div class="">
                <div class="google-map-canvas" id="map-canvas"></div>
            </div>
        </div>
        <div class="panel-footer clearfix">
        </div>
    </div>
</div>
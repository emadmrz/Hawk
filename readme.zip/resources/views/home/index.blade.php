لینک های موقتی
<ul>
    <li><a href="{{ route('profile.setting.password') }}" >تغییر کلمه عبور</a></li>
    <li><a href="{{ route('admin.users.list') }}" >مدیریت کاربران</a></li>
    <li><a href="{{ url('auth/logout') }}" >خروج از حساب کاربری</a></li>
</ul>
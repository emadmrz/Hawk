<?php
/**
 * Created By Dara on 9/11/2015
 * handling the report config
 */
return[
    'title'=>[
        '1'=>'موضوعات بی ارتباط با محتوای سایت',
        '2'=>'محتوای نا متعارف سیاسی',
        '3'=>'محتوای خلاف اخلاق'
    ]
];
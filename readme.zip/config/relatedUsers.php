<?php

/**
 * Created By  Dara on 23/11/2015
 * related users search variables
 */
return[
    'skillParam'=>20,
    'provinceParam'=>5,
    'cityParam'=>10,
    'firstCategoryParam'=>10,
    'secondCategoryParam'=>10
];